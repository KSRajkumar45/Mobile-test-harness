import React from 'react';

class App extends React.Component {
   render() {
      return (
         <div>
            Hello React Js App!!!
         </div>
      );
   }
}
export default App;
